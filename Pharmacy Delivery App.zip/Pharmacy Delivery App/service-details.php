<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Navbar with Background Image</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="styles.css">
</head>

<body>
    <!-- Navigation Bar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="#">Pharmacy Delivery App</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
                aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="#">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">About</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">Services</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">Contact</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Hero Section with Background Image -->
    <div class="hero-section">
        <div class="container text-center text-white">
            <h1>Welcome to My Website</h1>
            <p>Your one-stop destination for amazing services.</p>
        </div>
    </div>
    <section id="tracking system">
        <?php
require 'db.php';

$status = '';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $tracking_id = $_POST['tracking_id'];
    $stmt = $pdo->prepare("SELECT * FROM deliveries WHERE tracking_id = ?");
    $stmt->execute([$tracking_id]);
    $delivery = $stmt->fetch();

    if ($delivery) {
        $status = "Delivery Status: " . $delivery['delivery_status'];
    } else {
        $status = "Tracking ID not found.";
    }
}
?>
        <!DOCTYPE html>
        <html lang="en">

        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Delivery Tracking</title>
            <link rel="stylesheet"
                href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css">
        </head>

        <body>
            <div class="container mt-5">
                <h1 class="text-center">Delivery Tracking System</h1>
                <form method="POST" class="mt-4">
                    <div class="mb-3">
                        <label for="tracking_id" class="form-label">Enter Tracking ID:</label>
                        <input type="text" id="tracking_id" name="tracking_id" class="form-control" required>
                    </div>
                    <button type="submit" class="btn btn-primary">Track</button>
                </form>
                <?php if ($status): ?>
                <div class="alert alert-info mt-3">
                    <?php echo $status?>
                </div>
                <?php endif; ?>
            </div>
        </body>

        </html>

    </section>
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>