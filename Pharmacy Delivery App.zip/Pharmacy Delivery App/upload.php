<?php
$servername = "localhost"; // Change this to your database server
$username = "root";        // Your database username
$password = "";            // Your database password
$dbname = "pharmacy delivery app";      // Your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $patient_name = $_POST['patient_name'];
    $doctor_name = $_POST['doctor_name'];
    
    // Check if a file is uploaded
    if (isset($_FILES['file']) && $_FILES['file']['error'] == 0) {
        $file_tmp_name = $_FILES['file']['tmp_name'];
        $file_name = $_FILES['file']['name'];
        $file_size = $_FILES['file']['size'];
        $file_type = $_FILES['file']['type'];
        
        // Define the file upload path
        $upload_dir = 'uploads/';
        $file_path = $upload_dir . basename($file_name);

        // Move the uploaded file to the target directory
        if (move_uploaded_file($file_tmp_name, $file_path)) {
            // Prepare SQL query to insert data into the database
            $stmt = $conn->prepare("INSERT INTO prescriptions (patient_name, doctor_name, prescription_file) VALUES (?, ?, ?)");
            $stmt->bind_param("sss", $patient_name, $doctor_name, $file_path);
            
            if ($stmt->execute()) {
                // Redirect to the success page
                header("Location: index.php");
                exit(); // Ensure no further code is executed after the redirect
            } else {
                echo "<div class='alert alert-danger'>Error saving data to the database.</div>";
            }

            $stmt->close();
        } else {
            echo "<div class='alert alert-danger'>Failed to upload the file.</div>";
        }
    } else {
        echo "<div class='alert alert-danger'>Please choose a file to upload.</div>";
    }
}

$conn->close();
?>
