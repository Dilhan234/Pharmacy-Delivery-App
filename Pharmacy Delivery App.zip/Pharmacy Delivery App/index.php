<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <title>Pharmacy Delivery App</title>
    <meta name="description" content="">
    <meta name="keywords" content="">

    <!-- Favicons -->
    <link href="assets/img/favicon.png" rel="icon">
    <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com" rel="preconnect">
    <link href="https://fonts.gstatic.com" rel="preconnect" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Raleway:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap"
        rel="stylesheet">

    <!-- Vendor CSS Files -->
    <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
    <link href="assets/vendor/aos/aos.css" rel="stylesheet">
    <link href="assets/vendor/animate.css/animate.min.css" rel="stylesheet">
    <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
    <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

    <!-- Main CSS File -->
    <link href="assets/css/main.css" rel="stylesheet">
<style>
    h2 {
    color: #333;
    font-size: 30px;
    margin-bottom: 30px;
}


/* Form styles */
.form-group label {
    font-weight: bold;
    color: #555;
}

.form-control {
    border-radius: 5px;
    border: 1px solid #ccc;
    padding: 10px;
    margin-bottom: 20px;
    font-size: 16px;
}

.form-control:focus {
    border-color: #007bff;
    box-shadow: 0 0 5px rgba(0, 123, 255, 0.5);
}

/* Buttons */
.btn-primary {
    background-color: #007bff;
    border-color: #007bff;
    font-size: 16px;
    padding: 10px 20px;
    border-radius: 5px;
    transition: background-color 0.3s ease;
}

.btn-primary:hover {
    background-color: #0056b3;
    border-color: #0056b3;
}

/* Alert messages */
.alert {
    border-radius: 5px;
    font-size: 16px;
}

.alert-success {
    background-color: #28a745;
    color: white;
}

.alert-danger {
    background-color: #dc3545;
    color: white;
}

.alert-warning {
    background-color: #ffc107;
    color: white;
}
</style>

</head>

<body class="index-page">

    <header id="header" class="header d-flex align-items-center fixed-top">
        <div class="container-fluid container-xl position-relative d-flex align-items-center justify-content-between">

            <a href="index.html" class="logo d-flex align-items-center">
                <!-- Uncomment the line below if you also wish to use an image logo -->
                <!-- <img src="assets/img/logo.png" alt=""> -->
                <h1 class="sitename">Pharmacy Delivery App</h1>
            </a>

            <nav id="navmenu" class="navmenu">
                <ul>
                    <li><a href="#hero" class="active">Home</a></li>
                    <li><a href="#about">About</a></li>
                    <li><a href="#services">Services</a></li>
                    <li>
                        <a href="#upload">Upload</a>
                    </li>
                    <li><a href="#portfolio">Portfolio</a></li>
                    <li><a href="#product">Product</a></li>
                    <li><a href="#team">Team</a></li>
                    <li class="dropdown"><a href="#"><span>Dropdown</span> <i class="bi bi-chevron-down toggle-dropdown"></i></a>
                        <ul>
                            <li><a href="#">Dropdown 1</a></li>
                            <li class="dropdown"><a href="#"><span>Deep Dropdown</span> <i class="bi bi-chevron-down toggle-dropdown"></i></a>
                                <ul>
                                    <li><a href="#">Deep Dropdown 1</a></li>
                                    <li><a href="#">Deep Dropdown 2</a></li>
                                    <li><a href="#">Deep Dropdown 3</a></li>
                                    <li><a href="#">Deep Dropdown 4</a></li>
                                    <li><a href="#">Deep Dropdown 5</a></li>
                                </ul>
                            </li>
                            <li><a href="#">Dropdown 2</a></li>
                            <li><a href="#">Dropdown 3</a></li>
                            <li><a href="#">Dropdown 4</a></li>
                        </ul>
                    </li>
                    <li><a href="#contact">Contact</a></li>
                </ul>
                <i class="mobile-nav-toggle d-xl-none bi bi-list"></i>
            </nav>

        </div>
    </header>

    <main class="main">

        <!-- Hero Section -->
        <section id="hero" class="hero section dark-background">

            <div id="hero-carousel" data-bs-interval="5000" class="container carousel carousel-fade" data-bs-ride="carousel">

                <!-- Slide 1 -->
                <div class="carousel-item active">
                    <div class="carousel-container">
                        <h2 class="animate__animated animate__fadeInDown">Welcome to <span>Our Pharmacy Delivery App</span></h2>
                        <p class="animate__animated animate__fadeInUp">"ඔබගේ අයදුම්පත හරහා අපේ ඖෂධ බෙදාහැරීමේ සේවාව සමඟ, ඔබට පහසුවෙන් ඔබගේ අවශ්‍ය ඖෂධ මිතුරන්ගේ ආරක්ෂාව සහ පහසුව සඳහා ගෙවීම් කල හැකිය. අපගේ යෙදුම හරහා ඔබට ඖෂධ ඇණවුම් කිරීමට, ඔබගේ ලිපිනය හා දුරකථන අංකය ඇතුළත් කිරීමට හැකි අතර, එවක් ඔබට
                            ඖෂධ පහසු සහ වේගවත් බෙදාහැරීමක් ලැබේ. අපගේ විශ්වාසනීය සේවාව ඔබට අවශ්‍ය ඖෂධ නිවැරදිව සහ වේගයෙන් ලැබීමට සහය දේ."</p>
                        <a href="#about" class="btn-get-started animate__animated animate__fadeInUp scrollto">Read More</a>
                    </div>
                </div>

                <!-- Slide 2 -->
                <div class="carousel-item">
                    <div class="carousel-container">
                        <h2 class="animate__animated animate__fadeInDown">Pharmacy Delivery App</h2>
                        <p class="animate__animated animate__fadeInUp">"ඔබගේ අයදුම්පත හරහා අපේ ඖෂධ බෙදාහැරීමේ සේවාව සමඟ, ඔබට පහසුවෙන් ඔබගේ අවශ්‍ය ඖෂධ මිතුරන්ගේ ආරක්ෂාව සහ පහසුව සඳහා ගෙවීම් කල හැකිය. අපගේ යෙදුම හරහා ඔබට ඖෂධ ඇණවුම් කිරීමට, ඔබගේ ලිපිනය හා දුරකථන අංකය ඇතුළත් කිරීමට හැකි අතර, එවක් ඔබට
                            ඖෂධ පහසු සහ වේගවත් බෙදාහැරීමක් ලැබේ. අපගේ විශ්වාසනීය සේවාව ඔබට අවශ්‍ය ඖෂධ නිවැරදිව සහ වේගයෙන් ලැබීමට සහය දේ."</p>
                        <a href="#about" class="btn-get-started animate__animated animate__fadeInUp scrollto">Read More</a>
                    </div>
                </div>

                <!-- Slide 3 -->
                <div class="carousel-item">
                    <div class="carousel-container">
                        <h2 class="animate__animated animate__fadeInDown">Pharmacy Delivery App</h2>
                        <p class="animate__animated animate__fadeInUp">"ඔබගේ අයදුම්පත හරහා අපේ ඖෂධ බෙදාහැරීමේ සේවාව සමඟ, ඔබට පහසුවෙන් ඔබගේ අවශ්‍ය ඖෂධ මිතුරන්ගේ ආරක්ෂාව සහ පහසුව සඳහා ගෙවීම් කල හැකිය. අපගේ යෙදුම හරහා ඔබට ඖෂධ ඇණවුම් කිරීමට, ඔබගේ ලිපිනය හා දුරකථන අංකය ඇතුළත් කිරීමට හැකි අතර, එවක් ඔබට
                            ඖෂධ පහසු සහ වේගවත් බෙදාහැරීමක් ලැබේ. අපගේ විශ්වාසනීය සේවාව ඔබට අවශ්‍ය ඖෂධ නිවැරදිව සහ වේගයෙන් ලැබීමට සහය දේ."</p>
                        <a href="#about" class="btn-get-started animate__animated animate__fadeInUp scrollto">Read More</a>
                    </div>
                </div>

                <a class="carousel-control-prev" href="#hero-carousel" role="button" data-bs-slide="prev">
                    <span class="carousel-control-prev-icon bi bi-chevron-left" aria-hidden="true"></span>
                </a>

                <a class="carousel-control-next" href="#hero-carousel" role="button" data-bs-slide="next">
                    <span class="carousel-control-next-icon bi bi-chevron-right" aria-hidden="true"></span>
                </a>

            </div>

            <svg class="hero-waves" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 24 150 28 " preserveAspectRatio="none">
        <defs>
          <path id="wave-path" d="M-160 44c30 0 58-18 88-18s 58 18 88 18 58-18 88-18 58 18 88 18 v44h-352z"></path>
        </defs>
        <g class="wave1">
          <use xlink:href="#wave-path" x="50" y="3"></use>
        </g>
        <g class="wave2">
          <use xlink:href="#wave-path" x="50" y="0"></use>
        </g>
        <g class="wave3">
          <use xlink:href="#wave-path" x="50" y="9"></use>
        </g>
      </svg>

        </section>
        <!-- /Hero Section -->

        <!-- About Section -->
        <section id="about" class="about section">

            <div class="container">

                <div class="row position-relative">

                    <div class="col-lg-7 about-img" data-aos="zoom-out" data-aos-delay="200"><img src="assets/img/about.jpg" style="top: 30vh;"></div>

                    <div class="col-lg-7" data-aos="fade-up" data-aos-delay="100">
                        <h2 class="inner-title">Pharmacy Delivery App</h2>
                        <div class="our-story">
                            <h4>Pharmacy Delivery App</h4>
                            <h3>Our Story</h3>
                            <p>"ඔබගේ අයදුම්පත හරහා අපේ ඖෂධ බෙදාහැරීමේ සේවාව සමඟ, ඔබට පහසුවෙන් ඔබගේ අවශ්‍ය ඖෂධ මිතුරන්ගේ ආරක්ෂාව සහ පහසුව සඳහා ගෙවීම් කල හැකිය. අපගේ යෙදුම හරහා ඔබට ඖෂධ ඇණවුම් කිරීමට, ඔබගේ ලිපිනය හා දුරකථන අංකය ඇතුළත් කිරීමට හැකි අතර, එවක්
                                ඔබට ඖෂධ පහසු සහ වේගවත් බෙදාහැරීමක් ලැබේ. අපගේ විශ්වාසනීය සේවාව ඔබට අවශ්‍ය ඖෂධ නිවැරදිව සහ වේගයෙන් ලැබීමට සහය දේ.".</p>
                            <ul>
                                <li><i class="bi bi-check-circle"></i> <span>"අපගේ ඖෂධ බෙදාහැරීමේ සේවාව" </span></li>
                                <li><i class="bi bi-check-circle"></i> <span>"අපගේ ඖෂධ බෙදාහැරීමේ සේවාව" </span></li>
                                <li><i class="bi bi-check-circle"></i> <span>"අපගේ ඖෂධ බෙදාහැරීමේ සේවාව" </span></li>
                            </ul>
                            <p>"ඔබගේ අයදුම්පත හරහා අපේ ඖෂධ බෙදාහැරීමේ සේවාව සමඟ, ඔබට පහසුවෙන් ඔබගේ අවශ්‍ය ඖෂධ මිතුරන්ගේ ආරක්ෂාව සහ පහසුව සඳහා ගෙවීම් කල හැකිය. අපගේ යෙදුම හරහා ඔබට ඖෂධ ඇණවුම් කිරීමට, ඔබගේ ලිපිනය හා දුරකථන අංකය ඇතුළත් කිරීමට හැකි අතර, එවක්
                                ඔබට ඖෂධ පහසු සහ වේගවත් බෙදාහැරීමක් ලැබේ. අපගේ විශ්වාසනීය සේවාව ඔබට අවශ්‍ය ඖෂධ නිවැරදිව සහ වේගයෙන් ලැබීමට සහය දේ."</p>

                            <div class="watch-video d-flex align-items-center position-relative">
                                <i class="bi bi-play-circle"></i>
                                <a href="https://www.youtube.com/watch?v=Y7f98aduVJ8" class="glightbox stretched-link">Watch Video</a>
                            </div>
                        </div>
                    </div>

                </div>

            </div>

        </section>
        <!-- /About Section -->

        <!-- Clients Section -->
        <section id="clients" class="clients section light-background">

            <div class="container" data-aos="fade-up">

                <div class="row gy-4">

                    <div class="col-xl-2 col-md-3 col-6 client-logo">
                        <img src="assets/img/clients/client-1.png" class="img-fluid" alt="">
                    </div>
                    <!-- End Client Item -->

                    <div class="col-xl-2 col-md-3 col-6 client-logo">
                        <img src="assets/img/clients/client-2.png" class="img-fluid" alt="">
                    </div>
                    <!-- End Client Item -->

                    <div class="col-xl-2 col-md-3 col-6 client-logo">
                        <img src="assets/img/clients/client-3.png" class="img-fluid" alt="">
                    </div>
                    <!-- End Client Item -->

                    <div class="col-xl-2 col-md-3 col-6 client-logo">
                        <img src="assets/img/clients/client-4.png" class="img-fluid" alt="">
                    </div>
                    <!-- End Client Item -->

                    <div class="col-xl-2 col-md-3 col-6 client-logo">
                        <img src="assets/img/clients/client-5.png" class="img-fluid" alt="">
                    </div>
                    <!-- End Client Item -->

                    <div class="col-xl-2 col-md-3 col-6 client-logo">
                        <img src="assets/img/clients/client-6.png" class="img-fluid" alt="">
                    </div>
                    <!-- End Client Item -->

                </div>

            </div>

        </section>
        <!-- /Clients Section -->

        <!-- Features 2 Section -->
        <section id="features-2" class="features section features-2">

            <!-- Section Title -->
            <div class="container section-title" data-aos="fade-up">
                <h2>Features</h2>
                <p>"අපගේ ඖෂධ බෙදාහැරීමේ සේවාව පූර්ණයෙන්ම ආරක්ෂිත සහ වෛද්‍ය කටයුතු සඳහා පරිසරය හෝ සෞඛ්‍ය බලපෑමක් නොමැති බව සහතික කරයි. </p>
            </div>
            <!-- End Section Title -->
            <div class="container">
                <div class="row gy-4 justify-content-between">
                    <div class="features-image col-lg-4 d-flex align-items-center" data-aos="fade-up">
                        <img src="assets/img/features.png" class="img-fluid" alt="">
                    </div>
                    <div class="col-lg-7 d-flex flex-column justify-content-center">

                        <!-- Feature 1: Ordering Medicines -->
                        <div class="features-item d-flex" data-aos="fade-up" data-aos-delay="200">
                            <i class="bi bi-basket flex-shrink-0"></i>
                            <!-- Shopping Basket Icon -->
                            <div>
                                <h4>ඖෂධ ඇණවුම් කිරීම</h4>
                                <p>ඔබගේ අවශ්‍ය ඖෂධ සෙවීම සහ කිහිපයෙකුගේ ක්ලික් තුළම ඇණවුම් කිරීම පහසුය.</p>
                            </div>
                        </div>
                        <!-- End Features Item-->

                        <!-- Feature 2: Fast Delivery -->
                        <div class="features-item d-flex mt-5" data-aos="fade-up" data-aos-delay="300">
                            <i class="bi bi-truck flex-shrink-0"></i>
                            <!-- Delivery Truck Icon -->
                            <div>
                                <h4>වේගවත් බෙදාහැරීම</h4>
                                <p>ඔබගේ ඖෂධ ගෙදර වෙත කිහිපයෙකුගේ ඇණවුම් ක්‍රමය මඟින් වේගයෙන් බෙදාහැරීමට ලබා ගත හැකිය.</p>
                            </div>
                        </div>
                        <!-- End Features Item-->

                        <!-- Feature 3: Medication Tracking -->
                        <div class="features-item d-flex mt-5" data-aos="fade-up" data-aos-delay="400">
                            <i class="bi bi-pill flex-shrink-0"></i>
                            <!-- Pill Bottle Icon -->
                            <div>
                                <h4>ඖෂධ අනුගමනය කිරීම</h4>
                                <p>ඔබගේ ඖෂධ ඇණවුම් හා බෙදාහැරීමේ තත්ත්වය ත්‍රිවිධව අනුගමනය කරන්න.</p>
                            </div>
                        </div>
                        <!-- End Features Item-->

                        <!-- Feature 4: Secure Payment -->
                        <div class="features-item d-flex mt-5 " data-aos="fade-up" data-aos-delay="500">
                            <i class="bi bi-credit-card flex-shrink-0"></i>
                            <!-- Credit Card Icon -->
                            <div>
                                <h4>ආරක්ෂිත ගෙවීම්</h4>
                                <p>ඔබේ ගෙවීම් විවිධ ගෙවීම් ක්‍රම ඔස්සේ ආරක්ෂිතව සිදුකරගත හැකිය.</p>
                            </div>
                        </div>
                        <!-- End Features Item-->
                    </div>
                </div>
            </div>



            </div>
            </div>

            </div>

        </section>
        <!-- /Features 2 Section -->
        <!--/product---------------->
            <section id="product" class="product section">

            <div class="container">

                <div class="row position-relative">

                     <div class="container my-5">
        <h1 class="text-center mb-4">ඖෂධ සෙවීම</h1>
        <form method="GET" action="index.php" class="mb-4">
            <div class="input-group">
                <input type="text" name="query" class="form-control" placeholder="ඖෂධ නම හෝ ප්‍රවර්ගය සෙවන්න" required>
                <button class="btn btn-primary" type="submit">සෙවන්න</button>
            </div>
        </form>

        <div class="row">
            <?php
            $conn = new mysqli("localhost", "root", "", "pharmacy delivery app");
            if ($conn->connect_error) {
                die("සම්බන්ධතාවය අසාර්ථක විය: " . $conn->connect_error);
            }

            $query = $_GET['query'] ?? '';
            $sql = "SELECT * FROM medicines WHERE name LIKE '%$query%' OR category LIKE '%$query%'";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo '
                    <div class="col-md-4 mb-4">
                        <div class="card">
                            <img src="assets/img/Pharmacy/image 02.jpg" class="card-img-top" alt="Medicine Image">
                            <div class="card-body">
                                <h5 class="card-title">' . $row['name'] . '</h5>
                                <p class="card-text">ප්‍රවර්ගය: ' . $row['category'] . '</p>
                                <p class="card-text">මිල: රු. ' . $row['price'] . '</p>
                                <p class="card-text">ගබඩාවේ ඉතිරි ප්‍රමාණය: ' . $row['stock'] . '</p>
                                <a href="order.php?id=' . $row['id'] . '" class="btn btn-success">ඇනවුම කරන්න</a>
                            </div>
                        </div>
                    </div>';
                }
            } else {
                echo '<p class="text-center">ඇත්ම ඖෂධයක් හමු නොවීය.</p>';
            }

            $conn->close();
            ?>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>
                </div>

            </div>

        </section>

        <!-------------------------->
        <!-- Services Section -->
        <section id="services" class="services section">

            <!-- Section Title -->
            <div class="container section-title" data-aos="fade-up">
                <h2>Services</h2>
                <p>"අපගේ ඖෂධ බෙදාහැරීමේ සේවාව පූර්ණයෙන්ම ආරක්ෂිත සහ වෛද්‍ය කටයුතු සඳහා පරිසරය හෝ සෞඛ්‍ය බලපෑමක් නොමැති බව සහතික කරයි."</p>
            </div>
            <!-- End Section Title -->

            <div class="container">
                <div class="row gy-4">

                    <!-- Service 1: Medicine Ordering -->
                    <div class="col-lg-4 col-md-6" data-aos="fade-up" data-aos-delay="100">
                        <div class="service-item position-relative">
                            <div class="icon">
                                <i class="bi bi-cart-check"></i>
                                <!-- Cart Check Icon -->
                            </div>
                            <a href="service-details.html" class="stretched-link">
                                <h3>ඖෂධ ඇණවුම් කිරීම</h3>
                            </a>
                            <p>ඔබට පහසු ලෙස ඖෂධ ඇණවුම් කිරීමට සහ ගෙදර පමණක් ලැබීමට අපගේ සේවාව භාවිතා කරන්න.</p>
                        </div>
                    </div>
                    <!-- End Service Item -->

                    <!-- Service 2: Delivery Tracking -->
                    <div class="col-lg-4 col-md-6" data-aos="fade-up" data-aos-delay="200">
                        <div class="service-item position-relative">
                            <div class="icon">
                                <i class="bi bi-truck"></i>
                                <!-- Delivery Truck Icon -->
                            </div>
                            <a href="service-details.php" class="stretched-link">
                                <h3>බෙදාහැරීම අනුගමනය කිරීම</h3>
                            </a>
                            <p>ඔබේ ඖෂධ බෙදාහැරීමේ තත්ත්වය නිරන්තරයෙන් අනුගමනය කරන්න.</p>
                        </div>
                    </div>
                    <!-- End Service Item -->

                    <!-- Service 3: Prescription Management -->
                    <div class="col-lg-4 col-md-6" data-aos="fade-up" data-aos-delay="300">
                        <div class="service-item position-relative">
                            <div class="icon">
                                <i class="bi bi-file-earmark-medical"></i>
                                <!-- Prescription Icon -->
                            </div>
                            <a href="service-details.html" class="stretched-link">
                                <h3>ප්‍රතිකාර පතුරු කළමනාකරණය</h3>
                            </a>
                            <p>ඔබගේ ප්‍රතිකාර පතුරුවල සලස්වීම සහ කළමනාකරණය කරන ලදි.</p>
                        </div>
                    </div>
                    <!-- End Service Item -->

                    <!-- Service 4: Medicine Reminder -->
                    <div class="col-lg-4 col-md-6" data-aos="fade-up" data-aos-delay="400">
                        <div class="service-item position-relative">
                            <div class="icon">
                                <i class="bi bi-alarm"></i>
                                <!-- Alarm Icon -->
                            </div>
                            <a href="service.php" class="stretched-link">
                                <h3>ඖෂධ මතක් කිරීම</h3>
                            </a>
                            <p>ඔබට ඖෂධ ගන්නා වේලාව අමතක නොවන්න සඳහා මතක් කිරීමක් ලබා දේ.</p>
                        </div>
                    </div>
                    <!-- End Service Item -->

                    <!-- Service 5: Customer Support -->
                    <div class="col-lg-4 col-md-6" data-aos="fade-up" data-aos-delay="500">
                        <div class="service-item position-relative">
                            <div class="icon">
                                <i class="bi bi-headset"></i>
                                <!-- Customer Support Icon -->
                            </div>
                            <a href="service-details.html" class="stretched-link">
                                <h3>පාරිභෝගික සහාය</h3>
                            </a>
                            <p>ඔබගේ පාරිභෝගික අසනීපතා සඳහා 24/7 සහාය ලබා දේ.</p>
                        </div>
                    </div>
                    <!-- End Service Item -->

                    <!-- Service 6: Secure Payment -->
                    <div class="col-lg-4 col-md-6" data-aos="fade-up" data-aos-delay="600">
                        <div class="service-item position-relative">
                            <div class="icon">
                                <i class="bi bi-credit-card"></i>
                                <!-- Credit Card Icon -->
                            </div>
                            <a href="service-details.html" class="stretched-link">
                                <h3>ආරක්ෂිත ගෙවීම්</h3>
                            </a>
                            <p>අපගේ සේවා භාවිතා කර ඔබට විවිධ ආරක්ෂිත ගෙවීම් ක්‍රම භාවිතා කිරීමට හැකියාව ඇත.</p>
                        </div>
                    </div>
                    <!-- End Service Item -->

                </div>
            </div>


            </div>

            </div>

        </section>
        <!-- /Services Section -->

        <!-- Call To Action Section -->
        <section id="call-to-action" class="call-to-action section dark-background">

            <img src="assets/img/cta-bg.jpg" alt="">

            <div class="container">
                <div class="row justify-content-center" data-aos="zoom-in" data-aos-delay="100">
                    <div class="col-xl-10">
                        <div class="text-center">
                            <h3>Call To Pharmacy Owner</h3>
                            <p>"අපගේ ඖෂධ බෙදාහැරීමේ සේවාව පූර්ණයෙන්ම ආරක්ෂිත සහ වෛද්‍ය කටයුතු සඳහා පරිසරය හෝ සෞඛ්‍ය බලපෑමක් නොමැති බව සහතික කරයි."</p>
                            <a class="cta-btn" href="#">Call To owner </a>
                        </div>
                    </div>
                </div>
            </div>

        </section>
        <!-- /Call To Action Section -->

        <!-- upload Section -->
        <section id="upload" class="upload section">

            <div class="container">

                  <div class="container mt-5">
        <h2 class="text-center">Upload Prescription</h2>
        <form action="upload.php" method="post" enctype="multipart/form-data">
            <div class="form-group">
                <label for="patient_name">Patient Name:</label>
                <input type="text" class="form-control" id="patient_name" name="patient_name" required>
            </div>
            <div class="form-group">
                <label for="doctor_name">Doctor Name:</label>
                <input type="text" class="form-control" id="doctor_name" name="doctor_name" required>
            </div>
            <div class="form-group">
                <label for="file">Upload Prescription File:</label>
                <input type="file" class="form-control" id="file" name="file" required>
            </div>
            <button type="submit" class="btn btn-primary">Upload</button>
        </form>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

                </div>

            </div>

        </section>
        <!-- /upload Section -->

        <!-- Faq Section -->
        <section id="faq" class="faq section">

            <!-- Section Title -->
            <div class="container section-title" data-aos="fade-up">
                <h2>සමහර වේලාවට අසන ලද ප්‍රශ්න</h2>
                <p>අවශ්‍යතා පිළිබඳව සහ සංකීර්ණ ගැටළු සම්බන්ධයෙන් අපව විමසන්න.</p>
            </div>
            <!-- End Section Title -->

            <div class="container">

                <div class="row justify-content-center">

                    <div class="col-lg-10" data-aos="fade-up" data-aos-delay="100">

                        <div class="faq-container">

                            <div class="faq-item faq-active">
                                <h3>ඔබට අපගේ ඖෂධ භාර දීමේ සේවාව කොහොමද ලබා ගත හැකිද?</h3>
                                <div class="faq-content">
                                    <p>අපගේ ඖෂධ භාර දීමේ සේවාව ඔබගේ නගරයට හා ඔබගේ ගෘහ ලිපිනයට සහ පහසු වෙළඳපොල භාණ්ඩයන් වෙත ලබා ගත හැකි වේ.</p>
                                </div>
                                <i class="faq-toggle bi bi-chevron-right"></i>
                            </div>
                            <!-- End Faq item-->

                            <div class="faq-item">
                                <h3>ඔබගේ ඖෂධ භාර දීමේ කාලසටහන කුමක්ද?</h3>
                                <div class="faq-content">
                                    <p>අපගේ සේවා කාලසටහන සති මධ්‍යයේ දින කිහිපයක් ලෙස තිබේ. නිශ්චිත වේලාවන් හා පැමිණිලි සඳහා අපව විමසන්න.</p>
                                </div>
                                <i class="faq-toggle bi bi-chevron-right"></i>
                            </div>
                            <!-- End Faq item-->

                            <div class="faq-item">
                                <h3>ඔබගේ සේවාව භාවිතා කිරීම සඳහා මට කොයි රුපියල් ගාස්තුක් ලැබේද?</h3>
                                <div class="faq-content">
                                    <p>භාර දීමේ ගාස්තු ඔබේ භාණ්ඩවල ප්‍රමාණය සහ ගමනේ දුර මත පදනම්ව වෙනස් වේ.</p>
                                </div>
                                <i class="faq-toggle bi bi-chevron-right"></i>
                            </div>
                            <!-- End Faq item-->

                            <div class="faq-item">
                                <h3>මට ඖෂධ ලබා ගැනීමට කොපමණ කාලයක් ගතවන්නේද?</h3>
                                <div class="faq-content">
                                    <p>ඔබගේ ඖෂධය සම්පූර්ණයෙන්ම ලබා ගැනීම සඳහා සාමාන්‍යයෙන් 1-2 පැය ගතවිය හැකි අතර, ඔබගේ ප්‍රදේශයේ පවත්නා සේවා අනුව වෙනස් විය හැකිය.</p>
                                </div>
                                <i class="faq-toggle bi bi-chevron-right"></i>
                            </div>
                            <!-- End Faq item-->

                            <div class="faq-item">
                                <h3>කෝල් මගින් ඇනවුම් කළාට පසුව, මට ඇනවුම් කළ භාණ්ඩය දකින්න පුළුවන්ද?</h3>
                                <div class="faq-content">
                                    <p>ඔව්, ඔබට ඔබේ ඇනවුමට සහ ඖෂධයක්/භාණ්ඩය සම්බන්ධ තොරතුරු සඳහා අපගේ වෙබ් අඩවිය හෝ අපගේ කේන්ද්‍රීය සේවා අංකය හරහා පරීක්ෂා කළ හැකිය.</p>
                                </div>
                                <i class="faq-toggle bi bi-chevron-right"></i>
                            </div>
                            <!-- End Faq item-->

                            <div class="faq-item">
                                <h3>ඔබගේ සේවාව භාවිතා කිරීම සඳහා මට ලියාපදිංචි වීම අවශ්‍යද?</h3>
                                <div class="faq-content">
                                    <p>ඔව්, ඔබට ප්‍රථම වතාවට අපගේ සේවාව භාවිතා කිරීමට ලියාපදිංචි විය යුතුයි. පසුව, ඔබට ඔබගේ පැමිණිලි, බිල්පත් සහ ගැටලු කළමනාකරණය සඳහා පහසුකම් සැපයීමේ පද්ධතිය ඇත.</p>
                                </div>
                                <i class="faq-toggle bi bi-chevron-right"></i>
                            </div>
                            <!-- End Faq item-->

                        </div>

                    </div>
                    <!-- End Faq Column-->

                </div>

            </div>

        </section>
        <!-- /Faq Section -->


        <!-- Team Section -->
        <section id="team" class="team section">

            <!-- Section Title -->
            <div class="container section-title" data-aos="fade-up">
                <h2>Team</h2>
                <p>"ඔබගේ අයදුම්පත හරහා අපේ ඖෂධ බෙදාහැරීමේ සේවාව සමඟ, ඔබට පහසුවෙන් ඔබගේ අවශ්‍ය ඖෂධ මිතුරන්ගේ ආරක්ෂාව සහ පහසුව සඳහා ගෙවීම් කල හැකිය.</p>
            </div>
            <!-- End Section Title -->

            <div class="container">

                <div class="row">

                    <div class="col-lg-4 col-md-6 d-flex" data-aos="fade-up" data-aos-delay="100">
                        <div class="member">
                            <img src="assets/img/team/team-1.jpg" class="img-fluid" alt="">
                            <div class="member-content">
                                <h4>Walter White</h4>
                                <span>Web Development</span>
                                <p>
                                    Magni qui quod omnis unde et eos fuga et exercitationem. Odio veritatis perspiciatis quaerat qui aut aut aut
                                </p>
                                <div class="social">
                                    <a href=""><i class="bi bi-twitter-x"></i></a>
                                    <a href=""><i class="bi bi-facebook"></i></a>
                                    <a href=""><i class="bi bi-instagram"></i></a>
                                    <a href=""><i class="bi bi-linkedin"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Team Member -->

                    <div class="col-lg-4 col-md-6 d-flex" data-aos="fade-up" data-aos-delay="200">
                        <div class="member">
                            <img src="assets/img/team/team-2.jpg" class="img-fluid" alt="">
                            <div class="member-content">
                                <h4>Sarah Jhinson</h4>
                                <span>Marketing</span>
                                <p>
                                    Repellat fugiat adipisci nemo illum nesciunt voluptas repellendus. In architecto rerum rerum temporibus
                                </p>
                                <div class="social">
                                    <a href=""><i class="bi bi-twitter-x"></i></a>
                                    <a href=""><i class="bi bi-facebook"></i></a>
                                    <a href=""><i class="bi bi-instagram"></i></a>
                                    <a href=""><i class="bi bi-linkedin"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Team Member -->

                    <div class="col-lg-4 col-md-6 d-flex" data-aos="fade-up" data-aos-delay="300">
                        <div class="member">
                            <img src="assets/img/team/team-3.jpg" class="img-fluid" alt="">
                            <div class="member-content">
                                <h4>William Anderson</h4>
                                <span>Content</span>
                                <p>
                                    Voluptas necessitatibus occaecati quia. Earum totam consequuntur qui porro et laborum toro des clara
                                </p>
                                <div class="social">
                                    <a href=""><i class="bi bi-twitter-x"></i></a>
                                    <a href=""><i class="bi bi-facebook"></i></a>
                                    <a href=""><i class="bi bi-instagram"></i></a>
                                    <a href=""><i class="bi bi-linkedin"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Team Member -->

                </div>

            </div>

        </section>
        <!-- /Team Section -->

        <!-- Gallery Section -->
        <section id="gallery" class="gallery section">

            <!-- Section Title -->
            <div class="container section-title" data-aos="fade-up">
                <h2>Gallery</h2>
                <p>"ඔබගේ අයදුම්පත හරහා අපේ ඖෂධ බෙදාහැරීමේ සේවාව සමඟ, ඔබට පහසුවෙන් ඔබගේ අවශ්‍ය ඖෂධ මිතුරන්ගේ ආරක්ෂාව සහ පහසුව සඳහා ගෙවීම් කල හැකිය.</p>
            </div>
            <!-- End Section Title -->

            <div class="container-fluid" data-aos="fade-up" data-aos-delay="100">

                <div class="row g-0">

                    <div class="col-lg-3 col-md-4">
                        <div class="gallery-item">
                            <a href="assets/img/gallery/gallery-1.jpg" class="glightbox" data-gallery="images-gallery">
                                <img src="assets/img/gallery/gallery-1.jpg" alt="" class="img-fluid">
                            </a>
                        </div>
                    </div>
                    <!-- End Gallery Item -->

                    <div class="col-lg-3 col-md-4">
                        <div class="gallery-item">
                            <a href="assets/img/gallery/gallery-2.jpg" class="glightbox" data-gallery="images-gallery">
                                <img src="assets/img/gallery/gallery-2.jpg" alt="" class="img-fluid">
                            </a>
                        </div>
                    </div>
                    <!-- End Gallery Item -->

                    <div class="col-lg-3 col-md-4">
                        <div class="gallery-item">
                            <a href="assets/img/gallery/gallery-3.jpg" class="glightbox" data-gallery="images-gallery">
                                <img src="assets/img/gallery/gallery-3.jpg" alt="" class="img-fluid">
                            </a>
                        </div>
                    </div>
                    <!-- End Gallery Item -->

                    <div class="col-lg-3 col-md-4">
                        <div class="gallery-item">
                            <a href="assets/img/gallery/gallery-4.jpg" class="glightbox" data-gallery="images-gallery">
                                <img src="assets/img/gallery/gallery-4.jpg" alt="" class="img-fluid">
                            </a>
                        </div>
                    </div>
                    <!-- End Gallery Item -->

                    <div class="col-lg-3 col-md-4">
                        <div class="gallery-item">
                            <a href="assets/img/gallery/gallery-5.jpg" class="glightbox" data-gallery="images-gallery">
                                <img src="assets/img/gallery/gallery-5.jpg" alt="" class="img-fluid">
                            </a>
                        </div>
                    </div>
                    <!-- End Gallery Item -->

                    <div class="col-lg-3 col-md-4">
                        <div class="gallery-item">
                            <a href="assets/img/gallery/gallery-6.jpg" class="glightbox" data-gallery="images-gallery">
                                <img src="assets/img/gallery/gallery-6.jpg" alt="" class="img-fluid">
                            </a>
                        </div>
                    </div>
                    <!-- End Gallery Item -->

                    <div class="col-lg-3 col-md-4">
                        <div class="gallery-item">
                            <a href="assets/img/gallery/gallery-7.jpg" class="glightbox" data-gallery="images-gallery">
                                <img src="assets/img/gallery/gallery-7.jpg" alt="" class="img-fluid">
                            </a>
                        </div>
                    </div>
                    <!-- End Gallery Item -->

                    <div class="col-lg-3 col-md-4">
                        <div class="gallery-item">
                            <a href="assets/img/gallery/gallery-8.jpg" class="glightbox" data-gallery="images-gallery">
                                <img src="assets/img/gallery/gallery-8.jpg" alt="" class="img-fluid">
                            </a>
                        </div>
                    </div>
                    <!-- End Gallery Item -->

                </div>

            </div>

        </section>
        <!-- /Gallery Section -->

        <!-- Contact Section -->
        <section id="contact" class="contact section">

            <!-- Section Title -->
            <div class="container section-title" data-aos="fade-up">
                <h2>අප හා සම්බන්ධ වන්න</h2>
                <p>ඔබගේ ප්‍රශ්න සහ ඉල්ලීම් සඳහා අප හා සම්බන්ධ වීමට එවක් පමණක්.</p>
            </div>
            <!-- End Section Title -->

            <div class="container" data-aos="fade" data-aos-delay="100">

                <div class="row gy-4">

                    <div class="col-lg-4">
                        <div class="info-item d-flex" data-aos="fade-up" data-aos-delay="200">
                            <i class="bi bi-geo-alt flex-shrink-0"></i>
                            <div>
                                <h3>ලිපිනය</h3>
                                <p>A108 Adam Street, New York, NY 535022</p>
                            </div>
                        </div>
                        <!-- End Info Item -->

                        <div class="info-item d-flex" data-aos="fade-up" data-aos-delay="300">
                            <i class="bi bi-telephone flex-shrink-0"></i>
                            <div>
                                <h3>අප අමතන්න</h3>
                                <p>+1 5589 55488 55</p>
                            </div>
                        </div>
                        <!-- End Info Item -->

                        <div class="info-item d-flex" data-aos="fade-up" data-aos-delay="400">
                            <i class="bi bi-envelope flex-shrink-0"></i>
                            <div>
                                <h3>අපට විද්‍යුත් තැපැල් යවන්න</h3>
                                <p>info@example.com</p>
                            </div>
                        </div>
                        <!-- End Info Item -->

                    </div>

                    <div class="col-lg-8">
                        <form action="forms/contact.php" method="post" class="php-email-form" data-aos="fade-up" data-aos-delay="200">
                            <div class="row gy-4">

                                <div class="col-md-6">
                                    <input type="text" name="name" class="form-control" placeholder="ඔබේ නම" required="">
                                </div>

                                <div class="col-md-6">
                                    <input type="email" class="form-control" name="email" placeholder="ඔබේ විද්‍යුත් තැපැල්" required="">
                                </div>

                                <div class="col-md-12">
                                    <input type="text" class="form-control" name="subject" placeholder="විෂය" required="">
                                </div>

                                <div class="col-md-12">
                                    <textarea class="form-control" name="message" rows="6" placeholder="පණිවිඩය" required=""></textarea>
                                </div>

                                <div class="col-md-12 text-center">
                                    <div class="loading">ලෝඩ් වෙමින් ඇත</div>
                                    <div class="error-message"></div>
                                    <div class="sent-message">ඔබේ පණිවිඩය යවා ඇත. ඔබට ස්තුතියි!</div>

                                    <button type="submit">පණිවිඩය යවන්න</button>
                                </div>

                            </div>
                        </form>
                    </div>
                    <!-- End Contact Form -->

                </div>

            </div>

        </section>
        <!-- /Contact Section -->

    </main>



    <!-- Scroll Top -->
    <a href="#" id="scroll-top" class="scroll-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

    <!-- Preloader -->
    <div id="preloader"></div>

    <!-- Vendor JS Files -->
    <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="assets/vendor/php-email-form/validate.js"></script>
    <script src="assets/vendor/aos/aos.js"></script>
    <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
    <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>

    <!-- Main JS File -->
    <script src="assets/js/main.js"></script>

</body>

</html>


