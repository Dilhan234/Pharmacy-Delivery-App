<?php
$conn = new mysqli("localhost", "root", "", "pharmacy delivery app");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $order_id = $_POST['order_id'];
    $sql = "SELECT o.id, o.status, o.payment_status, m.name AS medicine 
            FROM orders o 
            JOIN medicines m ON o.medicine_id = m.id 
            WHERE o.id = $order_id";
    $result = $conn->query($sql);
    $order = $result->fetch_assoc();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Track Order</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container my-5">
        <h1 class="text-center">Track Your Order</h1>
        <form method="POST" class="mb-4">
            <div class="input-group">
                <input type="text" name="order_id" class="form-control" placeholder="Enter Order ID" required>
                <button class="btn btn-primary" type="submit">Track</button>
            </div>
        </form>

        <?php if (!empty($order)): ?>
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Order ID: <?php echo $order['id']; ?></h5>
                    <p class="card-text">Medicine: <?php echo $order['medicine']; ?></p>
                    <p class="card-text">Order Status: <?php echo $order['status']; ?></p>
                    <p class="card-text">Payment Status: <?php echo $order['payment_status']; ?></p>
                </div>
            </div>
        <?php elseif ($_SERVER['REQUEST_METHOD'] === 'POST'): ?>
            <p class="text-danger">Order not found.</p>
        <?php endif; ?>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
