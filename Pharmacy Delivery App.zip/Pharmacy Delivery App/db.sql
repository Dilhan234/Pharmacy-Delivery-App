CREATE TABLE medicines (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    category VARCHAR(50) NOT NULL,
    price DECIMAL(10, 2) NOT NULL,
    stock INT NOT NULL
);

CREATE TABLE orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    medicine_id INT NOT NULL,
    customer_name VARCHAR(100) NOT NULL,
    customer_email VARCHAR(100) NOT NULL,
    status VARCHAR(50) DEFAULT 'Pending',
    payment_status VARCHAR(50) DEFAULT 'Unpaid',
    FOREIGN KEY (medicine_id) REFERENCES medicines(id)
);
INSERT INTO medicines (name, category, price, stock) VALUES
('පැරසටමෝල්', 'වෙදනාවෙන් සැනසීම', 50.00, 100),
('ඇමොක්සිසෙලින්', 'ජීව කාන්දය', 150.00, 50),
('අයිබුප්රොෆෙන්', 'වෙදනාවෙන් සැනසීම', 120.00, 200),
('සෙටිරිසින්', 'ඇලර්ජි', 80.00, 150),
('ඇස්පිරිං', 'හෘද ආරක්ෂාව', 100.00, 100),
('ලොරටඩීන්', 'ඇලර්ජි', 90.00, 120),
('ඇසොමැක්', 'අස්ඩිටිටිය', 60.00, 300),
('ඔම්නික', 'මූත්‍රා තත්ත්ව', 250.00, 80),
('ඇටිවන්', 'නිදිමත', 200.00, 60),
('ඩයජින්', 'දියවැඩියාව', 70.00, 180),
('මෙට්ෆොර්මින්', 'දියවැඩියාව', 120.00, 150),
('රැන්ටිඩීන්', 'අස්ඩිටිටිය', 40.00, 400),
('අම්ලොඩිපයින්', 'පීඩනය', 30.00, 220),
('ලොසාර්ටාන්', 'පීඩනය', 35.00, 300),
('කැලරිසෝල්', 'ජීව කාන්දය', 140.00, 50),
('සයිප්‍රොෆ්ලොක්සසින්', 'ජීව කාන්දය', 160.00, 70),
('ඇටොරවාස්ටැටින්', 'කොලස්ටරෝල්', 100.00, 200),
('ග්ලයිබැන්ක්ලමිඩ්', 'දියවැඩියාව', 90.00, 180),
('ටෙට්‍රාසයික්ලින්', 'ජීව කාන්දය', 150.00, 40),
('ප්‍රෙඩ්නිසොලෝන්', 'ජලසන්ධාන', 120.00, 100);
