<?php
require 'db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $tracking_id = $_POST['tracking_id'];
    $customer_name = $_POST['customer_name'];
    $address = $_POST['address'];

    $stmt = $pdo->prepare("INSERT INTO deliveries (tracking_id, customer_name, address) VALUES (?, ?, ?)");
    $stmt->execute([$tracking_id, $customer_name, $address]);

    $message = "Delivery added successfully!";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Delivery</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css">
</head>
<body>
<div class="container mt-5">
    <h1 class="text-center">Add Delivery</h1>
    <?php if (!empty($message)): ?>
        <div class="alert alert-success">
            <?php echo $message; ?>
        </div>
    <?php endif; ?>
    <form method="POST" class="mt-4">
        <div class="mb-3">
            <label for="tracking_id" class="form-label">Tracking ID:</label>
            <input type="text" id="tracking_id" name="tracking_id" class="form-control" required>
        </div>
        <div class="mb-3">
            <label for="customer_name" class="form-label">Customer Name:</label>
            <input type="text" id="customer_name" name="customer_name" class="form-control" required>
        </div>
        <div class="mb-3">
            <label for="address" class="form-label">Address:</label>
            <textarea id="address" name="address" class="form-control" required></textarea>
        </div>
        <button type="submit" class="btn btn-success">Add Delivery</button>
    </form>
</div>
</body>
</html>
